import java.util.Scanner;

public class NumberOfStudents
{

    private int[] classes;
    private int[] height;
    private int total;
    private int numOfClasses;
    private int average;

    public ClassSize()
  {
    classes = new int[30];
    height = new int[]{0, -3, 1, 2, 3, 4, 3, 4, 4, 6, 8, 6, 6, 7, 10};

    total = 0;
    numOfClasses = 0;
    average = 0;
  }


          public static void main(String[] args){

}
