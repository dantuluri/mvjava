/*Surya Dantuluri
 * October 26, 2016
 * Pizza.java
 * Holds ingredients and price value of Pizza at fair.
 * 
 */


public class Pizza extends Food 
{
	
	public Pizza(String ingredient1)
	{
		super("baked", ingredient1,"pizza", 2.50, "dollars", 8, "(s)",1, "/n");
	} 
		
	}

