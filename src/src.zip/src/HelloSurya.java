/*Surya Dantuluri
August 24, 2016
HelloSurya
Simple application that (uses print() and println()) prints my name and a greeting. */
public class HelloSurya		//class declaration
{
	public static void main (String[]args)	//method header
	{
		System.out.print("\n\n\n");
		System.out.print("Hola Surya!");
		System.out.print("How are you doing?");
		System.out.print("Okay, how about you?");
		System.out.print("\n\n\n");

	}
}
































 
 
 
 
 
 
 
 
 
 
