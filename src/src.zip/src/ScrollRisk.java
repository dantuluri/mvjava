class ScrollRisk extends JPanel

{

	// public void makeGridLayout()
	// {
	// 	MyPanel panGL1, panGL2, panGL3, panGL4, panGL5, panGL6;
	// 	// Create a JFrame with BorderLayout
	// 	onlyFrame = new JFrame("GridLayout");	// Create the JFrame
	//
	// 	/////////////////////////////////////////////////
	// 	// Set the layout to GridLayout
	// 	onlyFrame.setLayout(new GridLayout(5,2));
	//
	// 	onlyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// 	onlyFrame.setSize(300, 300);
	// 	onlyFrame.setLocation(210, 120);
	//
	// 	// Create panels
	// 	panGL1 = new MyPanel(1, Color.RED);
	// 	panGL2 = new MyPanel(2, Color.BLUE);
	// 	panGL3 = new MyPanel(3, Color.GREEN);
	// 	panGL4 = new MyPanel(4, Color.ORANGE);
	// 	panGL5 = new MyPanel(5, Color.MAGENTA);
	// 	panGL6 = new MyPanel(6, Color.YELLOW);
	//
	// 	// Add panels to the frame
	// 	onlyFrame.getContentPane().add(panGL1);
	// 	onlyFrame.getContentPane().add(panGL2);
	// 	onlyFrame.getContentPane().add(panGL3);
	// 	onlyFrame.getContentPane().add(panGL4);
	// 	onlyFrame.getContentPane().add(panGL5);
	// 	onlyFrame.getContentPane().add(panGL6);

		// Make the JFrame visible
	//	onlyFrame.setVisible(true);
}
