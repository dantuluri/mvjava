


public class Food2 {
	
	public static void main (String args[]) {
		
	}
}

