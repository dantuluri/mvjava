/*Surya Dantuluri
 * DeepDishPizza.java
 * 
 *
 * 
 * 
 * 
 */


public class DeepDishPizza extends Pizza {
	
	public DeepDishPizza()
	{
		super("pepperoni");
	}
	
	public static void main (String args[]) {
		
		 
		
	}
}

