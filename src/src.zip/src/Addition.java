


public class Addition {
	
	public static void main (String[] args) {
		int a;
		for(a=0;a<5;a++)
		{
			System.out.println("hola" + a);
			int b = a*2;
			System.out.print(b+" ");
		}
	}
}

