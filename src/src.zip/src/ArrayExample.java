public class ArrayQuestion1 {
    public static void main(String[] args) {
        int array[] = new int [20];
        for (int a = 0; a < array.length; a++){
            array[a] = a;
        }
    }
}
