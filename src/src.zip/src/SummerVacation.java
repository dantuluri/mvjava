/*Surya Dantuluri
August 28, 2016
SummerVacation
Simple program that prints out what I did over the summer.*/
public class SummerVacation	//class declaration
{
	public static void main (String[]args)	//method header
	{
		System.out.print("\n\n\n");
		System.out.print("My Summer Vacation");
		System.out.print("\n\n");
		System.out.print("\t My summer vacation was great!");
				System.out.print("\n");
								System.out.print("\n");

		System.out.println("\t Over the summer I went to Berkeley everyday by BART to attend a presitgous business academy");
						System.out.print("\n");
						System.out.print("\n");

		System.out.print("\t I also slept a lot and ate a lot of food, in general I was lazy");
						System.out.print("\n");
						System.out.print("\n");

		System.out.print("\t Copa Americano Centanario was on TV and I watched every soccer match in the championship");
						System.out.print("\n");
								System.out.print("\n");

		System.out.print("\t I also watched Euro 2016, the soccer championship and I was happy when Portugal won!");
						System.out.print("\n");
								System.out.print("\n");

		System.out.print("\t I also made my own Roth IRA retirement account since I got my first paycheck, and I will be managing it for the future. ");
						System.out.print("\n");
						System.out.print("\n");

		System.out.print("\t ");
		System.out.print("\n\n\n");
	}
		
}
