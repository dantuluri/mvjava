/*Surya Dantuluri
 * Pizza.java
 * 
 * 
 * 
 */


public class Pizza extends Food 
{
	
	public Pizza(String ingredient1)
	{
		super("baked", ingredient1,"pizza", 2.50, "dollars", 8, "(s)",1);
	} 
		
	}

