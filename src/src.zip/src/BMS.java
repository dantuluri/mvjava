/*Surya Dantuluri
 * Period 2
 * October 26, 2016
 * bucklemyshoe.java
 * 
 * Simple program that takes input from user to output line of poem corresponding with input integer
 * Imports scanner first, and then makes main method
 * Gets input from user in different getInput() method
 * Then another method computes which number corresponds with poem line
 * Last method prints out output
 * 
 * Uses: 
 * if-else statements
 * 
 * 
 * Testing plan:
 * Valid Inputs: 0.0, 0.1, 1.5, 51.2, 103.7, or any positive integer
 * Invalid Inputs: Negative numbers, characters, strings, numbers less that 1 or greater than 10
 */


public class bucklemyshoe {
	
	public static void main (String args[]) 
	{
	//instatiate BMS
	Food food1 = new BMS
		
		
		
	}
}

